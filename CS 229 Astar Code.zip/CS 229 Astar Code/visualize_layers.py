import numpy as np
import matplotlib.pyplot as plt

def visualize_layers(npz_path, sample_idx=0):
    data = np.load(npz_path, allow_pickle=True)
    inputs = data['inputs']
    targets = data['targets']
    
    sample = inputs[sample_idx]
    layer_names = ['Obstacles', 'Start', 'Goal']
    
    # if path exists
    if sample.shape[0] == 4:
        layer_names.append('Path')
    
    plt.figure(figsize=(12, 3))
    # plot each layer in sample
    for i, layer in enumerate(sample):
        plt.subplot(1, sample.shape[0], i+1)
        plt.imshow(layer.T, cmap='gray', origin='lower')
        plt.title(layer_names[i])
        plt.axis('off')
    
    plt.show()

visualize_layers("data/train_dataset.npz", sample_idx=0)
