import numpy as np
import random
from astar_V1 import AStar, DetOccupancyGrid2D
import os


def random_rect_obstacles(max_obs=15, grid_size=64, max_size=15): 
    #generates random obstacle
    grid = np.zeros((grid_size, grid_size), dtype=np.float32)
    num_obs = np.random.randint(5,max_obs)
    for _ in range(num_obs):
        placed = False
        while not placed:
            x1, y1 = np.random.randint(0, grid_size - max_size, 2)
            w, h = np.random.randint(1, max_size, 2)
            if np.all(grid[x1:x1+w, y1:y1+h] == 0):
                grid[x1:x1+w, y1:y1+h] = 1.0
                placed = True
    return grid


def encode_input(grid, start, goal, path=None):
    start_layer = np.zeros_like(grid)
    goal_layer = np.zeros_like(grid)
    start_layer[start] = 1
    goal_layer[goal] = 1
    layers = [grid, start_layer, goal_layer]
    if path is not None:
        layers.append(path)
    inp = np.stack(layers, axis=0)  # (3 or 4,64,64)
    return inp


def coord_to_token(x, y, grid_size=64):
    return int(x * grid_size + y)


def token_to_coord(t, grid_size=64):
    return divmod(t, grid_size)


def generate_dataset(num_samples=1000, grid_size=64, output_path="dataset.npz", save_images = False):
    inputs, targets = [], []

    for i in range(num_samples):
        obstacles = random_rect_obstacles(max_obs=15, grid_size=grid_size)
        occupancy = DetOccupancyGrid2D(grid_size, grid_size, obstacles)

        while True:
            start = tuple(np.random.randint(0, grid_size, 2))
            goal = tuple(np.random.randint(0, grid_size, 2))
            if occupancy.is_free(start) and occupancy.is_free(goal):
                break

        astar = AStar((0, 0), (grid_size - 1, grid_size - 1),
                      start, goal, occupancy, resolution=1)

        success = astar.solve()
        if not success or not astar.path:
            continue

        path_tokens = [coord_to_token(x, y, grid_size) for (x, y) in astar.path]

        path_heatmap = np.zeros_like(obstacles)
        for x, y in astar.path:
            path_heatmap[x, y] = 1

        inp = encode_input(obstacles, start, goal, path=path_heatmap)

        inputs.append(inp)
        targets.append(np.array(path_tokens, dtype=np.int64))

        if save_images:
            image_path = f"data/sample_{i:04d}.png"
            astar.plot_path(save_path=image_path)

        if (i + 1) % 50 == 0:
            print(f"Generated {i + 1}/{num_samples} samples")

    np.savez_compressed(output_path, inputs=np.array(inputs, dtype=np.float32), targets=np.array(targets, dtype=object))
    print(f"\n Dataset saved to {output_path}")
    print(f"Total samples: {len(inputs)}")

    return inputs, targets

if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    generate_dataset(
        num_samples=1000,
        grid_size=64,
        output_path="data/train_dataset.npz",
        save_images=True
    )


